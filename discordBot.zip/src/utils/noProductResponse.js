export function noProductResponse() {
  return [
    {
      link: "Link do produto não encontrado",
      price: "Preço não encontrado",
      title: "Descrição não encontrada.",
    },
  ];
}
