export const COLORS = {
  AMAZON: parseInt("FFC107", 16),
  KABUM: parseInt("FF9900", 16),
  MERCADO_LIVRE: parseInt("FFFF00", 16),
  WARNING: parseInt("FF0000", 16),
  SUCCESS: parseInt("00FF00", 16),
};
